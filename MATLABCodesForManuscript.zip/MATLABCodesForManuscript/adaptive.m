function [ID] = adaptive(res)

% Function adaptive that takes in residue value and returns the table ID
% based on the decision region.

F = sum(abs(res)); % calculating the sum of the absolute value of residues.
N = length(res);   % N is the length of the residue.

% Decision regions
if F < 3*N         
    ID = '0';             
elseif F>3*N & F<=12*N  
        ID = '1';         
else
        ID = '0';
end
end

