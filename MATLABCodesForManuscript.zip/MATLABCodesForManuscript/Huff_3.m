function lucia_code = Huff_3(residue_vector, HuffmanTable1,HuffmanTable2, HuffmanTable3)

% Function that encodes blocks of data using the 3 tables of 3-Huffman
% Table ALEC and returns lucia_code.

lucia_code = '';                    % encoded bitstream.
code_1 = '';                        % empty bitstream for first iteration i =1.
code_2 = '';                        % store bitstream 
code_3 = '';                        %

N = length(residue_vector);         % block size of residues to be encoded.

for i = 1:N
 
% call encode function and encode blocks of data using the 1st table of Huffman coding Table A.   
ci1 = My_encode(residue_vector(i),HuffmanTable1); 
ciA = ci1;                                        % Set ciA to ci1.
code_1 = strcat(code_1,ciA); 

% call encode function and encode blocks of data using the 2nd table of Huffman coding Table B.
ci2 = My_encode(residue_vector(i),HuffmanTable2); 
ciB = ci2;                                        % Set ciB to ci2.
code_2 = strcat(code_2,ciB);

% call encode function and encode blocks of data using the 2nd table of Huffman coding Table B.
ci3 = My_encode(residue_vector(i),HuffmanTable3); 
ciC = ci3;              % Set ciC to ci3.
code_3 = strcat(code_3,ciC);
end

if length(char(code_1)) <= min(length(char(code_2)) && length(char(code_3)))
    ID = '10';
    lucia_code = strcat(ID,code_1);
elseif length(char(code_2)) <= min(length(char(code_1)) && length(char(code_3)))
    ID = '11';
    lucia_code = strcat(ID,code_2);
else
    length(char(code_3)) <= min(length(char(code_2)) && length(char(code_1)))
    ID = '0'
    lucia_code = strcat(ID,code_3);
end
return
end


