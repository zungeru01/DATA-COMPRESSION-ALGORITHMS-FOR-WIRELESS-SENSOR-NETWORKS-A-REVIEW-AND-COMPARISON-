clear;clc;

y = ''; % the final encoded bitstream.

fid1 = fopen('Table1.txt', 'r'); % open and read Table 1 text file.
table1 = textscan(fid1,'%d %s');
fclose(fid1);  
fid2 = fopen('Table2.txt', 'r'); % open and read Table 2 text file.
table2 = textscan(fid2,'%d %s');
fclose(fid2);
fid3 = fopen('Table3.txt', 'r');
table3 = textscan(fid3,'%d %s');
fclose(fid3);
source = [8202, 8202, 8202, 8201, 8202, 8202, 8202, 8208]; % Source data.

Block_size = input('Enter the desired block size    '); % A prompt to enter the desired block size.
%DR_Source = ceil(log2(max(source))); % The dynamic range of the source data.
residues = residual(source); % Calling residue function to compute the residue.
ID = adaptive(residues); % Calling adaptive function for Table ID.
%L = length(source);    % Size of source data.

code = Huff_4(residues,table1,table2,table3); % Calling 3 Huffman Table ALEC encode function to encode blocks of residues.
code = strcat(ID,code);

keyboard
if ID == '0'
    code = Huff_2(residues,table1,table2); % Calling 2 Huffman Table ALEC encode function to encode blocks of residues.
    code = strcat(ID,code);
else
    code = Huff_3(residues,table1,table2,table3); % Calling 3 Huffman Table ALEC encode function to encode blocks of residues.
    code = strcat(ID,code);
end

rem = mod(length(residues),Block_size);

% Encoding blocks of residues whose length is divisible by block-size
if rem == 0
    L = length(residues)/Block_size;       % L is the number of Block_sizes.
    code = '';
    code2 = '';
    for i = 1:L
        res_vector = residues((i-1)*Block_size+1:Block_size*i); % bock_sizes that do not have remainder.
        code_resvec = Huff_2(res_vector,table1,table2); % Calling 2 Huffman Table to encode res_vector.
        code = strcat(code,code_resvec);
        
            
        code_resvec2 = Huff_3(res_vector,table1,table2,table3); % Calling 3 Huffman Table to encode res_vector.
        code2 = strcat(code2,code_resvec2);
        
        
    end
    
   size_A = length(char(code));
   size_B = length(char(code2));
    if size_A <= size_B         % comparing the sizes of the encoded bitstreams.
        ID = '0';               % generating code identifier for 2 Huffman Table
        strm = strcat(ID,code);
    else 
        ID = '1';               % generating code identifier for 3 Huffman Table
        strm = strcat(ID,code2);
    end
    
    y = char(strcat(y,strm));
else
    code = '';
    code2 = '';
    L = floor(length(residues)/Block_size);
    for i = 1:L
        res_vector = residues((i-1)*Block_size+1:Block_size*i); % block sizes that leave remainders.
        code_resvec = Huff_2(res_vector,table1,table2); % Calling 2 Huffman Table to encode res_vector.
        code = strcat(code,code_resvec);
        
            
        code_resvec2 = Huff_3(res_vector,table1,table2,table3); % Calling 3 Huffman Table to encode res_vector.
        code2 = strcat(code2,code_resvec2);
    end
    if rem ~= 0
        
    % Encoding remaining block of residues.
    res_vector = residues(Block_size*L+1:end);
    code_MyRem = Huff_2(res_vector,table1,table2); % Calling 2 Huffman Table to encode remainder of blocks.
    codeE = strcat(code,code_MyRem);
        
    code_MyRem = Huff_3(res_vector,table1,table2,table3); % Calling 3 Huffman Tableto encode remainder of blocks.
    codeF = strcat(code2,code_MyRem);
    end
    
    size_C = length(char(codeE));
    size_D = length(char(codeF));
    
    if size_C <= size_D          % comparing 2 Huffman and 3 Huffman sizes of the encoded bitstreams(with remainders).
        ID = '0';                % generating code identifier for 2 Huffman Table
        strm = strcat(ID,codeE);
    else
        ID = '1';                % generating code identifier for 3 Huffman Table
        strm = strcat(ID,codeF);
    end
    
    y = char(strcat(y,strm));
    
   
end
      
       



    