function [residue] = residual(source) 
% function that takes the difference between readings of the source data 
% and calculates residues.

DR = ceil(log2(max(source))); % Dynamic range of the source data 
xo = 2^(DR-1);      % First residue

residue = zeros(1,length(source)); % initialising the residue vector.
residue(1) = source(1) - xo; % calculating the first residue.

for i = 2:length(source)

   residue(i) = source(i) - source(i-1);
    
end
return
end