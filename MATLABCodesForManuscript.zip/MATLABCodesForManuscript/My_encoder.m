function ci = My_encoder(residue_value,table1,table2,table3)
% This was written by Lucia KK on the 07 June 2021
% It encodes a residual vector using 3 Huffman tables.
% And returns an encoded bitstream, ci.

% Computing di category
C = table1{2};
D = table2{2};
E = table3{2};

    if residue_value == 0
        bi = 0;
    elseif abs(residue_value) == 1
        bi = 1;
    else
        bi = ceil(log2(abs(residue_value)));
    end
    
    if bi==0|| bi==1||bi==2
        hi = C(bi+1);
    elseif bi==3|| bi==4
        hi = E(bi+1);
    else
        hi = D(bi+1);
    end
    
% build ci1
if bi == 0
   ci = hi;
elseif residue_value < 0
    li = dec2bin(0);
    ci = strcat(hi,li);
    
      else    % build li
 li = dec2bin(residue_value);    % Set li to index |bi
 ci = strcat(hi,li);
end

return
end

