function code_1 = Huff_4(residue_vector, HuffmanTable1,HuffmanTable2, HuffmanTable3)

% Function that encodes blocks of data using the 3 tables of 3-Huffman
% Table ALEC and returns code_1.

code_1 = '';                        % empty bitstream for first iteration i =1.
N = length(residue_vector);         % block size of residues to be encoded.

for i = 1:N
% call My_encoder function to encode blocks of data using all 3 Huffman tables.  
ci1 = My_encoder(residue_vector(i),HuffmanTable1,HuffmanTable2,HuffmanTable3); 
ciA = ci1;                                        % Set ciA to ci1.
code_1 = strcat(code_1,ciA); 


end

return
end


