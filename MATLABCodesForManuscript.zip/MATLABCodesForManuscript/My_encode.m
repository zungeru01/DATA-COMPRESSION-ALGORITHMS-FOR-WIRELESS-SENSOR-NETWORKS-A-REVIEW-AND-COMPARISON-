function ci = My_encode(residue_value,table)
% function ci = My_encode(di,table).
% di is the residual vector.
% table is the Huffman table to be used.
% ci is the encoded bitstream.
% This was written by Lucia KK on the 31st May 2021
% It encodes a residual vector using a specified Huffman table.
% And returns an encoded bitstream.

%N = length(residue_vector);

% Computing di category
C = table{2};
%code = ''; 
%for i = 1: N
    if residue_value == 0
        bi = 0;
    elseif abs(residue_value) == 1
        bi = 1;
    else
        bi = ceil(log2(abs(residue_value)));
    end
    

hi = C(bi+1);
    
% build ci1
if bi == 0
   ci = hi;
elseif residue_value < 0
    li = dec2bin(0);
    ci = strcat(hi,li);
    
      else    % build li
 li = dec2bin(residue_value);    % Set li to index |bi
 ci = strcat(hi,li);
end
%code = strcat(code,ci);
%end
return
end

