function code = Huff_2(residue_vector, HuffmanTable1, HuffmanTable2)
% Lucia K Ketshabetswe.
% Function that encodes blocks of data using 2-Huffman Table ALEC.

code = '';          % encoded bitstream that is returned.
code1 = '';
code2 = '';
N = length(residue_vector);

for i = 1:N
 % calls My_encode function and encodes blocks of data using the 1st table of Huffman coding Table A.   
ci1 = My_encode(residue_vector(i),HuffmanTable1); 
ciA = ci1;              % Set ciA to ci1.
code1 = strcat(code1,ciA);

% calls encode function and encodesss blocks of data using the 2nd table of Huffman coding Table B.
ci2 = My_encode(residue_vector(i),HuffmanTable2); 
ciB = ci2;              % Set ciB to ci2.
code2 = strcat(code2,ciB);

end

if length(char(code1)) <= length(char(code2))
    ID = '0';
    code = strcat(ID,code1);
else
    ID = '1';
    code = strcat(ID,code2);
end

return
end
